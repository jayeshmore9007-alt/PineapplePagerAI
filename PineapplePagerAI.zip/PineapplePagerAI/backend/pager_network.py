import ipaddress
import socket
from urllib.parse import urlparse


def check_pager(base_url: str) -> dict:
    parsed = urlparse(base_url)
    if parsed.scheme not in ("http", "https"):
        return {"connected": False, "message": "Use an HTTP or HTTPS URL."}
    if not parsed.hostname:
        return {"connected": False, "message": "Invalid device address."}

    hostname = parsed.hostname
    try:
        ip = ipaddress.ip_address(hostname)
        if not ip.is_private:
            return {"connected": False, "message": "Only private network addresses are allowed."}
    except ValueError:
        return {"connected": False, "message": "Use a private LAN IP address for this check."}

    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        with socket.create_connection((hostname, port), timeout=5):
            return {"connected": True, "host": hostname, "port": port,
                    "message": "Network endpoint is reachable."}
    except OSError:
        return {"connected": False, "host": hostname, "port": port,
                "message": "Network endpoint is not reachable."}
