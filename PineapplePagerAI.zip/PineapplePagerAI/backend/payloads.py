PAYLOADS = [
    {"id": "dns", "name": "DNS Lookup", "description": "Resolve a domain name to IP addresses.", "risk": "Low", "requires_approval": True},
    {"id": "tls", "name": "TLS Certificate Check", "description": "Inspect a server HTTPS certificate.", "risk": "Low", "requires_approval": True},
    {"id": "inventory", "name": "Device Inventory", "description": "Record a device inventory entry.", "risk": "Low", "requires_approval": True},
]
