import json
import os
import urllib.request
import urllib.error


def ask_ai(message: str) -> str:
    api_key = os.getenv("AI_API_KEY", "")
    endpoint = os.getenv("AI_API_URL", "https://api.openai.com/v1/chat/completions")
    model = os.getenv("AI_MODEL", "gpt-4o-mini")

    if not api_key:
        return "AI API is not configured. Set AI_API_KEY on the backend server."

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": (
                "You are PineapplePager AI, an assistant for authorized network "
                "diagnostics. Only help with systems the user owns or is authorized "
                "to test. Do not provide credential theft, stealth, malware, or "
                "destructive instructions.")},
            {"role": "user", "content": message},
        ],
        "temperature": 0.3,
    }
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            result = json.loads(response.read().decode("utf-8"))
        return result["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as error:
        return f"AI provider HTTP error: {error.code}"
    except Exception as error:
        return f"AI provider error: {error}"
