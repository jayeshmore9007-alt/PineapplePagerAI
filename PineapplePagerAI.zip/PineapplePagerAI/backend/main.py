import os
import hmac
import socket
import ssl
from datetime import datetime, timezone

from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field

from ai_agent import ask_ai
from pager_network import check_pager
from payloads import PAYLOADS

app = FastAPI(title="PineapplePager AI", version="1.0.0")
activity_log = []


def require_token(supplied: str = Header(default="", alias="X-App-Token")):
    expected = os.getenv("APP_TOKEN", "")
    # Fail closed: if APP_TOKEN is not set, refuse requests.
    if not expected or not hmac.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Invalid application token.")


def log_activity(action: str, result: str):
    activity_log.append({"time": datetime.now(timezone.utc).isoformat(),
                         "action": action, "result": result})
    del activity_log[:-100]


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


class DeviceRequest(BaseModel):
    base_url: str = Field(min_length=8, max_length=300)


class DiagnosticRequest(BaseModel):
    payload_id: str
    target: str = Field(min_length=1, max_length=253)
    approved: bool = False


def clean_host(request: DiagnosticRequest) -> str:
    if not request.approved:
        raise HTTPException(status_code=403, detail="Explicit approval is required.")
    target = request.target.strip()
    if any(c in target for c in ["/", "\\", " ", "@"]):
        raise HTTPException(status_code=400, detail="Enter a hostname only.")
    return target


@app.get("/")
def home():
    return {"app": "PineapplePager AI", "status": "online", "safe_mode": True}


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.get("/payloads", dependencies=[Depends(require_token)])
def get_payloads():
    return {"payloads": PAYLOADS}


@app.get("/activity", dependencies=[Depends(require_token)])
def get_activity():
    return {"activity": activity_log}


@app.post("/assistant/chat", dependencies=[Depends(require_token)])
def assistant_chat(request: ChatRequest):
    answer = ask_ai(request.message)
    log_activity("AI Assistant", "Chat request processed")
    return {"success": True, "answer": answer}


@app.post("/device/check", dependencies=[Depends(require_token)])
def device_check(request: DeviceRequest):
    result = check_pager(request.base_url)
    log_activity("Pager network check", result["message"])
    return result


@app.post("/diagnostics/dns", dependencies=[Depends(require_token)])
def dns_lookup(request: DiagnosticRequest):
    target = clean_host(request)
    try:
        results = socket.getaddrinfo(target, None, type=socket.SOCK_STREAM)
        addresses = sorted({item[4][0] for item in results})
    except socket.gaierror:
        raise HTTPException(status_code=400, detail="DNS lookup failed.")
    log_activity("DNS Lookup", target)
    return {"success": True, "hostname": target, "addresses": addresses}


@app.post("/diagnostics/tls", dependencies=[Depends(require_token)])
def tls_check(request: DiagnosticRequest):
    target = clean_host(request)
    try:
        context = ssl.create_default_context()
        with socket.create_connection((target, 443), timeout=5) as conn:
            with context.wrap_socket(conn, server_hostname=target) as secure:
                cert = secure.getpeercert()
        log_activity("TLS Certificate Check", target)
        return {"success": True, "hostname": target,
                "certificate": cert.get("subject", []), "expires": cert.get("notAfter")}
    except (OSError, ssl.SSLError, ValueError):
        raise HTTPException(status_code=400, detail="TLS check failed.")
