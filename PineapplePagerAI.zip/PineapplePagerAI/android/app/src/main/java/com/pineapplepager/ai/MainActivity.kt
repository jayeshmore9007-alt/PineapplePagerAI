package com.pineapplepager.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                PineapplePagerApp()
            }
        }
    }
}

suspend fun apiRequest(
    baseUrl: String,
    token: String,
    path: String,
    method: String = "GET",
    body: JSONObject? = null
): String = withContext(Dispatchers.IO) {
    val url = URL(baseUrl.trimEnd('/') + path)
    val connection = url.openConnection() as HttpURLConnection
    try {
        connection.requestMethod = method
        connection.connectTimeout = 10000
        connection.readTimeout = 20000
        connection.setRequestProperty("Accept", "application/json")
        if (token.isNotBlank()) {
            connection.setRequestProperty("X-App-Token", token)
        }
        if (body != null) {
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() } ?: "No response"
        if (status !in 200..299) {
            throw Exception("HTTP $status: $response")
        }
        response
    } finally {
        connection.disconnect()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PineapplePagerApp() {
    var backend by remember { mutableStateOf("http://10.0.2.2:8000") }
    var token by remember { mutableStateOf("") }
    var pagerUrl by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("Welcome to PineapplePager AI") }
    var selectedTab by remember { mutableStateOf("Dashboard") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun runRequest(path: String, method: String = "GET", body: JSONObject? = null) {
        scope.launch {
            busy = true
            output = "Connecting..."
            try {
                output = apiRequest(backend, token, path, method, body)
            } catch (e: Exception) {
                output = "Error: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("PineapplePager AI") }) },
        bottomBar = {
            NavigationBar {
                listOf("Dashboard", "Assistant", "Payloads", "Devices", "Settings").forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {},
                        label = { Text(tab) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                "Dashboard" -> {
                    Text("Security Dashboard", style = MaterialTheme.typography.headlineSmall)
                    Button(onClick = { runRequest("/health") }, enabled = !busy) {
                        Text("Check Backend")
                    }
                    Button(onClick = { runRequest("/activity") }, enabled = !busy) {
                        Text("Activity Logs")
                    }
                    Text("Backend: $backend")
                }
                "Assistant" -> {
                    Text("AI Assistant", style = MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        label = { Text("Ask AI Assistant") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            runRequest("/assistant/chat", "POST", JSONObject().put("message", question))
                        },
                        enabled = !busy && question.isNotBlank()
                    ) { Text("Ask AI") }
                }
                "Payloads" -> {
                    Text("Safe Payload Manager", style = MaterialTheme.typography.headlineSmall)
                    Button(onClick = { runRequest("/payloads") }, enabled = !busy) {
                        Text("Load Payloads")
                    }
                    Text("Only approved diagnostic operations are supported.")
                }
                "Devices" -> {
                    Text("Pager Network Manager", style = MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(
                        value = pagerUrl,
                        onValueChange = { pagerUrl = it },
                        label = { Text("Pager Base URL") },
                        placeholder = { Text("https://192.168.1.10") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            runRequest("/device/check", "POST", JSONObject().put("base_url", pagerUrl))
                        },
                        enabled = !busy && pagerUrl.isNotBlank()
                    ) { Text("Check Pager Connection") }
                }
                "Settings" -> {
                    Text("Settings", style = MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(
                        value = backend,
                        onValueChange = { backend = it },
                        label = { Text("Backend URL") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it },
                        label = { Text("App Access Token") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("On a physical phone, use your server's LAN IP instead of 10.0.2.2.")
                }
            }

            HorizontalDivider()
            Text("Response", style = MaterialTheme.typography.titleMedium)
            if (busy) CircularProgressIndicator()
            Text(output)
        }
    }
}
