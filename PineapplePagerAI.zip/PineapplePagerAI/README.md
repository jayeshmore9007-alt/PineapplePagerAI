# PineapplePager AI

Android app + Python backend for authorized network diagnostics.

## Build the APK (GitHub)
1. Upload everything to a repo, commit to `main`.
2. Actions -> "PineapplePager AI APK Build" -> Run workflow.
3. Download the `PineapplePagerAI-APK` artifact (contains app-debug.apk).

## Backend
    cd backend
    pip install -r requirements.txt
    export APP_TOKEN=long_random_token AI_API_KEY=your_key
    uvicorn main:app --host 0.0.0.0 --port 8000

In the app: Settings -> set Backend URL (server LAN IP) and the same token.
